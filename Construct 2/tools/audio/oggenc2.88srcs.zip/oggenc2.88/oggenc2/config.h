#ifndef CONFIG_H
#define CONFIG_H 1

#define PACKAGE "vorbis-tools"
#define VERSION "1.4.0"

#endif /* CONFIG_H */
