/* OggEnc
 **
 ** This program is distributed under the GNU General Public License, version 2.
 ** A copy of this license is included with this source.
 **
 ** Copyright 2000, Michael Smith <msmith@labyrinth.net.au>
 **
 ** Portions from Vorbize, (c) Kenneth Arnold <kcarnold@yahoo.com>
 ** and libvorbis examples, (c) Monty <monty@xiph.org>
 **/

/* Platform support routines  - win32, OS/2, unix */


#include "platform.h"
#include "encode.h"
#include "i18n.h"
#include <stdlib.h>
#include <ctype.h>
#if defined(_WIN32) || defined(__EMX__) || defined(__WATCOMC__)
#include <fcntl.h>
#include <io.h>
#include <time.h>
#endif

#ifdef _WIN32
#include <windows.h>
#endif

#if defined(_WIN32) && defined(_MSC_VER)

void setbinmode(FILE *f)
{
	_setmode( _fileno(f), _O_BINARY );
}
#elif defined(_WIN32) && defined(__MINGW32__)

void setbinmode(FILE *f)
{
	_setmode( _fileno(f), _O_BINARY );
}
#endif /* win32 */

#ifdef __EMX__
void setbinmode(FILE *f) 
{
	        _fsetmode( f, "b");
}
#endif

#if defined(__WATCOMC__) || defined(__BORLANDC__)
void setbinmode(FILE *f)
{
	setmode(fileno(f), O_BINARY);
}
#endif


#if defined(_WIN32) || defined(__EMX__) || defined(__WATCOMC__)
void *timer_start(void)
{
	time_t *start = malloc(sizeof(time_t));
	time(start);
	return (void *)start;
}

double timer_time(void *timer)
{
	time_t now = time(NULL);
	time_t start = *((time_t *)timer);

    if(now-start)
    	return (double)(now-start);
    else
        return 1; /* To avoid division by zero later, for very short inputs */
}


void timer_clear(void *timer)
{
	free((time_t *)timer);
}

#else /* unix. Or at least win32 */

#include <sys/time.h>
#include <unistd.h>

void *timer_start(void)
{
	struct timeval *start = malloc(sizeof(struct timeval));
	gettimeofday(start, NULL);
	return (void *)start;
}

double timer_time(void *timer)
{
	struct timeval now;
	struct timeval start = *((struct timeval *)timer);

	gettimeofday(&now, NULL);

	return (double)now.tv_sec - (double)start.tv_sec + 
		((double)now.tv_usec - (double)start.tv_usec)/1000000.0;
}

void timer_clear(void *timer)
{
	free((time_t *)timer);
}

#endif

#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef _WIN32

#include <direct.h>

#define PATH_SEPS "/\\"
#define mkdir(x,y) _mkdir((x))

/* MSVC does this, borland doesn't? */
#ifndef __BORLANDC__
#define stat _stat
#endif

#else

#define PATH_SEPS "/"

#endif

//int create_directories(char *fn)
int create_directories(char *fn, int isutf8)
{
    char *end, *start;
    struct stat statbuf;
    char *segment = malloc(strlen(fn)+1);

    start = fn;
#ifdef _WIN32
    if(strlen(fn) >= 3 && isalpha(fn[0]) && fn[1]==':')
        start = start+2;
#endif

    while((end = strpbrk(start+1, PATH_SEPS)) != NULL)
    {
        int rv;
        memcpy(segment, fn, end-fn);
        segment[end-fn] = 0;

//        if(stat(segment,&statbuf)) {
#ifdef _WIN32
        
        if (isutf8) {
            wchar_t seg[MAX_PATH+1];
            MultiByteToWideChar(CP_UTF8, 0, segment, -1, seg, MAX_PATH+1);
            rv = _wstat(seg,&statbuf);
        } else
#endif
            rv = stat(segment,&statbuf);
        if(rv) {
            if(errno == ENOENT) {
                if(mkdir(segment, 0777)) {
                    fprintf(stderr, _("Couldn't create directory \"%s\": %s\n"),
                            segment, strerror(errno));
                    free(segment);
                    return -1;
                }
            }
            else {
                fprintf(stderr, _("Error checking for existence of directory %s: %s\n"), 
                            segment, strerror(errno));
                free(segment);
                return -1;
            }
        }
#if defined(_WIN32) && !defined(__BORLANDC__)
        else if(!(_S_IFDIR & statbuf.st_mode)) {
#elif defined(__BORLANDC__)
        else if(!(S_IFDIR & statbuf.st_mode)) {
#else
        else if(!S_ISDIR(statbuf.st_mode)) {
#endif
            fprintf(stderr, _("Error: path segment \"%s\" is not a directory\n"),
                    segment);
            free(segment);
            return -1;
        }

        start = end+1;
    }

    free(segment);
    return 0;

}

#ifdef _WIN32
 
FILE *oggenc_fopen(char *fn, char *mode, int isutf8)
{
    if (isutf8) {
        wchar_t wfn[MAX_PATH+1];
        wchar_t wmode[32];
        MultiByteToWideChar(CP_UTF8, 0, fn, -1, wfn, MAX_PATH+1);
        MultiByteToWideChar(CP_ACP, 0, mode, -1, wmode, 32);
        return _wfopen(wfn, wmode);
    } else
        return fopen(fn, mode);
}

typedef WINSHELLAPI LPWSTR *  (APIENTRY *tCommandLineToArgvW)(LPCWSTR lpCmdLine, int*pNumArgs);

void get_args_from_ucs16(int *argc, char ***argv, int *isutf8)
{
    OSVERSIONINFO vi;
    vi.dwOSVersionInfoSize = sizeof(vi);
    GetVersionEx(&vi);

    /* We only do NT4 and more recent.*/
    /* It would be relatively easy to add NT3.5 support. Is anyone still using NT3? */
    /* It would be relatively hard to add 9x support. Fortunately, 9x is
       a lost cause for unicode support anyway. */
    if (vi.dwPlatformId == VER_PLATFORM_WIN32_NT && vi.dwMajorVersion >= 4) {
        int newargc;
        int sizeofargs = 0;
        int a, count;
        char *argptr;
        char **newargv = NULL;
        LPWSTR *ucs16argv = NULL;
        tCommandLineToArgvW pCommandLineToArgvW = NULL;
        HMODULE hLib = NULL;
        
        hLib = LoadLibrary("shell32.dll");
        if (!hLib)
            goto bail;
        pCommandLineToArgvW = (tCommandLineToArgvW)GetProcAddress(hLib, "CommandLineToArgvW");
        if (!pCommandLineToArgvW)
            goto bail;

        ucs16argv = pCommandLineToArgvW(GetCommandLineW(), &newargc);
        if (!ucs16argv)
            goto bail;

        for (a=0; a<newargc; a++) {
            count = WideCharToMultiByte(CP_UTF8, 0, ucs16argv[a], -1,
                NULL, 0, NULL, NULL);
            if (count == 0)
                goto bail;
            sizeofargs += count;
        }

        newargv = malloc((newargc * sizeof(char *)) + sizeofargs);
        argptr = (char *)(&newargv[newargc]);

        for (a=0; a<newargc; a++) {
            count = WideCharToMultiByte(CP_UTF8, 0, ucs16argv[a], -1,
                argptr, sizeofargs, NULL, NULL);
            if (count == 0)
                goto bail;

            newargv[a] = argptr;
            argptr += count;
            sizeofargs -= count;
        }

        *argc = newargc;
        *argv = newargv;
        *isutf8 = 1;

bail:
        if (hLib != NULL)
            FreeLibrary(hLib);
        if (ucs16argv != NULL)
            GlobalFree(ucs16argv);
    }
}

#endif


