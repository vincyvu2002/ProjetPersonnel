/* OggEnc2.87
 *
 * This program is distributed under the GNU General Public License, version 2.
 * A copy of this license is included with this source.
 *
 * Copyright 2000-2005, Michael Smith <msmith@xiph.org>
 *
 * Portions from Vorbize, (c) Kenneth Arnold <kcarnold@yahoo.com>
 * and libvorbis examples, (c) Monty <monty@xiph.org>
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <getopt.h>
#include <string.h>
#include <time.h>
#include <locale.h>
#include <errno.h>
#include <sys/types.h>
#include <ctype.h>
#if defined WIN32 || defined _WIN32
#include <process.h>
#endif

#include "platform.h"
#include "encode.h"
#include "audio.h"
#include "utf8.h"
#include "i18n.h"

#ifdef INC_REHUFF
#include "recode.h"         /* for rehuff routine */
#endif

#ifndef MAX_PATH
#define MAX_PATH 256
#endif

#define CHUNK 4096 /* We do reads, etc. in multiples of this */

#define VERSION_STRING "OggEnc v2.88 (libvorbis 1.3.5)\n"
#define COPYRIGHT "(c) 2000-2015 Michael Smith <msmith@xiph.org>\n & portions by John Edwards <john.edwards33@ntlworld.com>\n"

#define FLAC      1
#define APE       2
#define WAVPACK   3
#define LPAC      4
#define OPTIMFROG 5
#define SHORTEN   6

struct option long_options[] = {
	{"quiet",0,0,'Q'},
	{"help",0,0,'h'},
	{"skeleton",no_argument,NULL,'k'},
	{"comment",1,0,'c'},
	{"artist",1,0,'a'},
	{"album",1,0,'l'},
	{"title",1,0,'t'},
	{"genre",1,0,'G'},
	{"names",1,0,'n'},
	{"name-remove",1,0,'X'},
	{"name-replace",1,0,'P'},
	{"output",1,0,'o'},
	{"version",0,0,'v'},
	{"raw",0,0,'r'},
	{"raw-format",1,0,'F'},
	{"raw-bits",1,0,'B'},
	{"raw-chan",1,0,'C'},
	{"raw-rate",1,0,'R'},
	{"raw-endianness",1,0, 0},
	{"bitrate",1,0,'b'},
	{"min-bitrate",1,0,'m'},
	{"max-bitrate",1,0,'M'},
	{"quality",1,0,'q'},
	{"date",1,0,'d'},
	{"tracknum",1,0,'N'},
	{"serial",1,0,'s'},
	{"managed", 0, 0, 0},
	{"converter",1,0,'S'},
	{"resample",1,0,0},
	{"downmix", 0,0,0},
	{"scale", 1, 0, 0},
	{"FLAC-scale", 1, 0, 0},
	{"advanced-encode-option", 1, 0, 0},
	{"discard-comments", 0, 0, 0},
/*	{"padding", 1, 0, 'p'}, ** Removed - Win 7 issues */
#ifdef INC_REHUFF
	{"rehuff", 0,0,0},
#endif
	{"utf8", 0,0,0},
	{"ignorelength", 0, 0, 0},
	{"lyrics",1,0,'L'},
	{"lyrics-language",1,0,'Y'},
	{NULL,0,0,0}
};

typedef struct taglist_FLAC {
	char *tag;
	struct taglist_FLAC *next_tag;
} taglist_F;

taglist_F *head_tag = NULL;

static char *generate_name_string(char *format, char *remove_list, 
        char *replace_list, char *artist, char *title, char *album, 
        char *track, char *date, char *genre);
/* static void parse_options(int argc, char **argv, oe_options *opt); */
static void parse_options(int *argc, char ***argv, int origargc, char **origargv, oe_options *opt);
static void build_comments(vorbis_comment *vc, oe_options *opt, int filenum, 
        char **artist,char **album, char **title, char **tracknum, char **date, char **genre);
static void usage(void);

/*
 * Create TAG list from FLAC Tags
 */
void add_TAG(char *flac_tag)
{
	char *tag_name;
	taglist_F *tag_entry, *tag_node;

	if (flac_tag == NULL)
		return;

	/* create entry */
	utf8_decode(flac_tag, &tag_name);
	tag_entry = (taglist_F *)malloc(sizeof(taglist_F));

	tag_entry->tag = tag_name;
	tag_entry->next_tag = NULL;

	/* insert entry */
	if (head_tag == NULL)
		head_tag = tag_entry;
	else {
		tag_node = head_tag;
		while (tag_node->next_tag != NULL)
			tag_node = tag_node->next_tag;

		tag_node->next_tag = tag_entry;
	}
}

/*
 * The caller is responsible for deleting the pointer
 */
char *_get_tag()
{
	char *tag_name;
	taglist_F *tag_entry;

	if (head_tag == NULL) {
		return NULL;
	}

	/* pop entry */
	tag_entry = head_tag;
	head_tag = head_tag->next_tag;

	tag_name = tag_entry->tag;
	free(tag_entry);

	return tag_name;
}

int tag_compare(const char *s1, const char *s2, int n)
{
	int c=0;
	while (c < n) {
		if (toupper(s1[c]) != toupper(s2[c]))
			return !0;
		c++;
	}
	return 0;
}

int str_no_case_comp(char const *str1, char const *str2, unsigned long len)
{
	signed int c1 = 0, c2 = 0;

	while (len--) {
		c1 = tolower(*str1++);
		c2 = tolower(*str2++);

		if (c1 == 0 || c1 != c2)
			break;
	}

	return c1 - c2;
}

int main(int argc, char **argv)
{
			     /* Default Values for encoder settings
			      */

	oe_options opt = {
				/* char **title	*/
				NULL,
				/* int title_count */
				0,
				/* char **artist */
				NULL,
				/* int artist_count */
				0,
				/* char **album */
				NULL,
				/* int album_count */
				0, 
			    /* char **comments */
				NULL,
				/*int comment_count */
				0,
				/* char **tracknum */
				NULL,
				/* int track_count */
				0,
				/* char **dates */
				NULL,
				/* int date_count */
				0, 
			    /* char **genre	*/
				NULL,
				/* int genre_count */
				0,
				/* char **lyrics */
				NULL,
				/* int lyrics_count */
				0,
				/* char **lyrics_language */
				NULL,
				/* int lyrics_language_count */
				0,
			    /* adv_opt *advopt */
				NULL,
				/* int advopt_count */
				0,
				/* int copy_comments */
				1,
				/* int with_skeleton */
				0,
				/* int quiet */
				0,
				/* int rawmode */
				0, 
			    /* int raw_format */
				1,
				/* int raw_samplesize */
				16,
				/* int raw_samplerate */
				44100,
				/* int raw_channels */
				2,
				/* int raw_endianness */
				0, 
			    /* char *namefmt */
				NULL,
				/* char *namefmt_remove */
				DEFAULT_NAMEFMT_REMOVE,
				/* char *namefmt_replace */
				DEFAULT_NAMEFMT_REPLACE,
				/* char *outfile */
				NULL,
			    /* int managed */
				0,
				/* int min_bitrate */
				-1,
				/* int nominal_bitrate */
				-1,
				/* int max_bitrate */
				-1,
			    /* int vbr_bitrate */
				0,
				/* float quality */
				.3,
				/* int quality_set */
				-1,
			    /* int resamplefreq */
				0,
				/* int converter */
				1,
				/* int downmix */
				0,
				/* float scale */
				0.0, 
			    /* int isutf8 */
				0,
				/* unsigned int serial */
				0,
				/* unsigned int skeleton_serial */
				0,
			    /* unsigned int kate_serial */
				0, 
			    /* int fixedserial */
				0,
				/* int padding */
				0,
				/* int rehuff */
				0,
				/* int FLAC_scale */
				0,
				/* int ignorelength */
				0}; 

	int i;

	char **infiles;
	char *temp_fn = "hufftemp.tmp";
	int numfiles;
	int errors=0;

	int origargc = argc;
	char **origargv = argv;
	get_args_from_ucs16(&argc, &argv, &opt.isutf8);

	setlocale(LC_ALL, "");
	bindtextdomain(PACKAGE, LOCALEDIR);
	textdomain(PACKAGE);

	/* parse_options(argc, argv, &opt); */
	parse_options(&argc, &argv, origargc, origargv, &opt);
	if(optind >= argc)
	{
		fprintf(stderr, _("ERROR: No input files specified. Use -h for help.\n"));
		return 1;
	}
	else
	{
		infiles = argv + optind;
		numfiles = argc - optind;
	}

	/* Now, do some checking for illegal argument combinations */

	for(i = 0; i < numfiles; i++)
	{
		if(!strcmp(infiles[i], "-") && numfiles > 1)
		{
			fprintf(stderr, _("ERROR: Multiple files specified when using stdin\n"));
			exit(1);
		}
	}

	if(numfiles > 1 && opt.outfile)
	{
		fprintf(stderr, _("ERROR: Multiple input files with specified output filename: suggest using -n\n"));
		exit(1);
	}

	if(!opt.fixedserial)
	{
                /* We randomly pick a serial number. This is then incremented for each
                   file. The random seed includes the PID so two copies of oggenc that
                   start in the same second will generate different serial numbers. */
                srand(time(NULL) ^ getpid());
		opt.serial = rand();
	}
	opt.skeleton_serial = opt.serial + numfiles;
	opt.kate_serial = opt.skeleton_serial + numfiles;

	for(i = 0; i < numfiles; i++)
	{
		/* Once through the loop for each file */

		oe_enc_opt      enc_opts;
		vorbis_comment  vc;
		char           *out_fn = NULL;
		FILE           *in, *out = NULL;
		int             foundformat = 0;
		int             closeout = 0, closein = 0;
		char           *artist=NULL, *album=NULL, *title=NULL, *track=NULL;
		char           *date=NULL, *genre=NULL;
		char           *fnp;
		char 		   *lyrics=NULL, *lyrics_language=NULL;
		input_format   *format;
		unsigned char   piped_input = 0;
		char           *flac_comment;
		unsigned int    j, k;
		char            tag_buf[MAX_PATH];
		double          gain_R = 0.0,
		                gain_A = 0.0;
		int             resample_used = 0;

		/* Set various encoding defaults */

		enc_opts.serialno = opt.serial++;
		enc_opts.skeleton_serialno = opt.skeleton_serial++;
		enc_opts.kate_serialno = opt.kate_serial++;
		enc_opts.progress_update = update_statistics_full;
		enc_opts.start_encode = start_encode_full;
		enc_opts.end_encode = final_statistics;
		enc_opts.error = encode_error;
		enc_opts.comments = &vc;
		enc_opts.copy_comments = opt.copy_comments;
		enc_opts.with_skeleton = opt.with_skeleton;
		enc_opts.FLAC_scale = opt.FLAC_scale;
		enc_opts.ignorelength = opt.ignorelength;

		/* OK, let's build the vorbis_comments structure */
		build_comments(&vc, &opt, i, &artist, &album, &title, &track, 
	                &date, &genre);

		if(opt.lyrics_count)
		{
			if(i >= opt.lyrics_count)
			{
				lyrics = NULL;
			}
			else
				lyrics = opt.lyrics[i];
		}

		if(opt.lyrics_language_count)
		{
			if(i >= opt.lyrics_language_count)
			{
				if(!opt.quiet)
					fprintf(stderr, _("WARNING: Insufficient lyrics languages specified, defaulting to final lyrics language.\n"));
					lyrics_language = opt.lyrics_language[opt.lyrics_language_count-1];
			}
			else
				lyrics_language = opt.lyrics_language[i];
		}

		if(!strcmp(infiles[i], "-"))
		{
			setbinmode(stdin);
			in = stdin;
			infiles[i] = NULL;
			if(!opt.outfile)
			{
				setbinmode(stdout);
				out = stdout;
			}
		}
		else
		{
			fnp = (char *)strrchr(infiles[i], '.');
			if(!str_no_case_comp(fnp, ".ape", 4)) {
				in = pipeopen ( "mac # - -d", infiles[i]);
				piped_input = 1;
			}
			else if(!str_no_case_comp(fnp, ".wv", 3)) {
				in = pipeopen ( "wvunpack # -", infiles[i]);
				piped_input = 1;
			}
			else if(!str_no_case_comp(fnp, ".pac", 4)) {
				in = pipeopen ( "lpac -x # - ", infiles[i]);
				piped_input = 1;
			}
			else if(!str_no_case_comp(fnp, ".ofr", 4)) {
				in = pipeopen ( "optimfrog d # - ", infiles[i]);
				piped_input = 1;
			}
			else if(!str_no_case_comp(fnp, ".shn", 4)) {
				in = pipeopen ( "shorten -x # - ", infiles[i]);
				piped_input = 1;
			}
			else
 				/* in = fopen(infiles[i], "rb"); */
 				in = oggenc_fopen(infiles[i], "rb", opt.isutf8);
		}
		
		if(in == NULL)
		{
			fprintf(stderr, _("ERROR: Cannot open input file \"%s\": %s\n"), infiles[i], strerror(errno));
			free(out_fn);
			errors++;
			continue;
		}

		closein = 1;
				
		/* Now, we need to select an input audio format - we do this before opening
		   the output file so that we don't end up with a 0-byte file if the input
		   file can't be read */

		if(opt.rawmode)
		{
			input_format raw_format = {NULL, 0, raw_open, wav_close, "raw",
				N_("RAW file reader")};

			enc_opts.format = opt.raw_format;
			enc_opts.rate = opt.raw_samplerate;
			enc_opts.channels = opt.raw_channels;
			if (enc_opts.format == 3)
				enc_opts.samplesize = 32;
			else
				enc_opts.samplesize = opt.raw_samplesize;
			enc_opts.endianness = opt.raw_endianness;
            
			format = &raw_format;
			format->open_func(in, &enc_opts, NULL, 0);
			foundformat=1;
		}
		else
		{
			format = open_audio_file(in, &enc_opts);
			if(format)
			{
				if(!opt.quiet)
					fprintf(stderr, _("Opening with %s module: %s\n"), 
					    	format->format, format->description);
				foundformat=1;
			}

		}

		if(!foundformat)
		{
			fprintf(stderr, _("ERROR: Input file \"%s\" is not a supported format\n"), infiles[i]?infiles[i]:"(stdin)");
			if(closein) {
				if(piped_input)
					PCLOSE(in);
				else
					fclose(in);
			}
			errors++;
			continue;
		}

		/* Ok. We can read the file - so now open the output file */

		if(opt.outfile && !strcmp(opt.outfile, "-"))
		{
			setbinmode(stdout);
			out = stdout;
		}
		else if(out == NULL)
		{
			if(opt.outfile)
			{
				out_fn = strdup(opt.outfile);
			}
			else if(opt.namefmt)
			{
				out_fn = generate_name_string(opt.namefmt, opt.namefmt_remove, 
				         opt.namefmt_replace, artist, title, album, track,date,
				         genre);
			}
			/* This bit was widely derided in mid-2002, so it's been removed */
/*
			else if(opt.title)
			{
				out_fn = malloc(strlen(title) + 5);
				strcpy(out_fn, title);
				strcat(out_fn, ".ogg");
			}
*/
			else if(infiles[i])
			{
				/* Create a filename from existing filename, replacing extension with .ogg or .oga */
				char *start, *end;
				char *extension;

				/* if adding Skeleton or Kate, we're not Vorbis I anymore */
				extension = (opt.with_skeleton || opt.lyrics_count>0) ? ".oga" : ".ogg";

				start = infiles[i];
				end = strrchr(infiles[i], '.');
				end = end?end:(start + strlen(infiles[i])+1);
			
				out_fn = malloc(end - start + 5);
				strncpy(out_fn, start, end-start);
				out_fn[end-start] = 0;
				strcat(out_fn, extension);
			}
			else {
				/* if adding skeleton or kate, we're not Vorbis I anymore */
				if (opt.with_skeleton || opt.lyrics_count>0)
					out_fn = strdup("default.oga");
				else
					out_fn = strdup("default.ogg");
				fprintf(stderr, _("WARNING: No filename, defaulting to \"%s\"\n"), out_fn);
			}

			/* Create any missing subdirectories, if possible */
			/* if(create_directories(out_fn)) { */
			if(create_directories(out_fn, opt.isutf8)) {
				if(closein) {
					if(piped_input)
						PCLOSE(in);
					else
						fclose(in);
				}
				fprintf(stderr, _("ERROR: Could not create required subdirectories for output filename \"%s\"\n"), out_fn);
				errors++;
				free(out_fn);
				continue;
			}

			if(infiles[i] && !strcmp(infiles[i], out_fn)) {
				fprintf(stderr, _("ERROR: Input filename is the same as output filename \"%s\"\n"), out_fn);
				errors++;
				free(out_fn);
				continue;
			}

			out = oggenc_fopen(out_fn, "wb", opt.isutf8);
			if(out == NULL)
			{
				if(closein) {
					if(piped_input)
						PCLOSE(in);
					else
						fclose(in);
				}
				fprintf(stderr, _("ERROR: Cannot open output file \"%s\": %s\n"), out_fn, strerror(errno));
				errors++;
				free(out_fn);
				continue;
			}	
			closeout = 1;
		}

		/* Now, set the rest of the options */
		enc_opts.out = out;
		enc_opts.comments = &vc;
		if (opt.isutf8) {
			/* TODO: error checking here */
			/* utf8_decode(out_fn, &enc_opts.filename); */
			/* utf8_decode(infiles[i], &enc_opts.infilename); */
			if (out_fn)
				utf8_decode(out_fn, &enc_opts.filename);
			else
				enc_opts.filename = NULL;

			if (infiles[i])
				utf8_decode(infiles[i], &enc_opts.infilename);
			else
				enc_opts.infilename = NULL;
		} else {
			enc_opts.filename = out_fn;
			enc_opts.infilename = infiles[i];
		}
		enc_opts.managed = opt.managed;
		enc_opts.bitrate = opt.nominal_bitrate; 
		enc_opts.min_bitrate = opt.min_bitrate;
		enc_opts.max_bitrate = opt.max_bitrate;
		enc_opts.quality = opt.quality;
		enc_opts.quality_set = opt.quality_set;
/*		enc_opts.padding = opt.padding*1024; ** Removed - Win 7 issues */
		enc_opts.advopt = opt.advopt;
		enc_opts.advopt_count = opt.advopt_count;
		enc_opts.lyrics = lyrics;
		enc_opts.lyrics_language = lyrics_language;

		if(opt.resamplefreq && opt.resamplefreq != enc_opts.rate) {
			int fromrate = enc_opts.rate;
			resample_used = 1;
			enc_opts.resamplefreq = opt.resamplefreq;
			enc_opts.converter = opt.converter;
			enc_opts.ratio = (1.0 * opt.resamplefreq) / enc_opts.rate ;
			if(setup_resample(&enc_opts)) {
				errors++;
				goto clear_all;
			}
			else if(!opt.quiet)
				fprintf(stderr, _("Resampling input from %d Hz to %d Hz\n"), fromrate, opt.resamplefreq);
		}

		if(opt.downmix) {
			if(enc_opts.channels == 2) {
				setup_downmix(&enc_opts);
				if(!opt.quiet)
					fprintf(stderr, _("Downmixing stereo to mono\n"));
			}
			else {
				fprintf(stderr, _("ERROR: Can't downmix except from stereo to mono\n"));
				errors++;
				if(opt.resamplefreq)
					clear_resample(&enc_opts);
				goto clear_all;
			}
		}

		if (opt.FLAC_scale) {
			while (flac_comment = _get_tag()) {
				if (!tag_compare(flac_comment, "RG_RADIO=", 9)) {
					for (j = 9, k = 0; j <= strlen(flac_comment); j++, k++)
						tag_buf[k] = flac_comment[j];
					gain_R = atof(tag_buf);
				}
				else if (!tag_compare(flac_comment, "REPLAYGAIN_TRACK_GAIN=", 22)) {
					for (j = 22, k = 0; j <= strlen(flac_comment); j++, k++)
						tag_buf[k] = flac_comment[j];
					gain_R = atof(tag_buf);
				}
				else if (!tag_compare(flac_comment, "RG_AUDIOPHILE=", 14)) {
					for (j = 14, k = 0; j <= strlen(flac_comment); j++, k++)
						tag_buf[k] = flac_comment[j];
					gain_A = atof(tag_buf);
				}
				else if (!tag_compare(flac_comment, "REPLAYGAIN_ALBUM_GAIN=", 22)) {
					for (j = 22, k = 0; j <= strlen(flac_comment); j++, k++)
						tag_buf[k] = flac_comment[j];
					gain_A = atof(tag_buf);
				}
			}
		}
		if (opt.FLAC_scale == 1)	// Title Gain
			opt.scale = pow(10., gain_R * 0.05);
		else if (opt.FLAC_scale == 2)	// Album Gain
			opt.scale = pow(10., gain_A * 0.05);

		if(opt.scale > 0.f) {
			setup_scaler(&enc_opts, opt.scale);
			if(!opt.quiet)
				fprintf(stderr, _("Scaling input to %f\n"), opt.scale);
		}

		
		if(!enc_opts.total_samples_per_channel)
			enc_opts.progress_update = update_statistics_notime;

		if(opt.quiet)
		{
			enc_opts.start_encode = start_encode_null;
			enc_opts.progress_update = update_statistics_null;
			enc_opts.end_encode = final_statistics_null;
		}

		if(oe_encode(&enc_opts))
			errors++;

		if(opt.scale > 0)
			clear_scaler(&enc_opts);
		if(opt.downmix)
			clear_downmix(&enc_opts);
		if(resample_used == 1)
			clear_resample(&enc_opts);

clear_all:

		if(out_fn) free(out_fn);
		if(opt.outfile) free(opt.outfile);
#ifdef _WIN32
        if(enc_opts.filename) free(enc_opts.filename);
        if(enc_opts.infilename) free(enc_opts.infilename);
#endif
		vorbis_comment_clear(&vc);
		format->close_func(enc_opts.readdata);

		if(closein) {
			if(piped_input)
				PCLOSE(in);
			else
				fclose(in);
		}
		if(closeout)
			fclose(out);
#ifdef INC_REHUFF
		if(opt.rehuff) {
			if(rename(out_fn, temp_fn) != 0)
				fprintf(stderr, _("Rename failed\n"));
			rehuff(temp_fn, out_fn, opt.serial+1, opt.quiet);
			remove(temp_fn);
		}
#endif
	}/* Finished this file, loop around to next... */

	return errors?1:0;

}

static void usage(void)
{
	fprintf(stdout, _("%s%s\n"), VERSION_STRING, COPYRIGHT);
	fprintf(stdout, _("Usage: oggenc2 [options] input.wav [...]\n\n"));
	fprintf(stdout, _("OPTIONS:\n"));
	fprintf(stdout, _(" General:\n"));
	fprintf(stdout, _(	" -Q, --quiet          Produce no output to stderr\n"));
	fprintf(stdout, _(	" -h, --help           Print this help text\n"));
	fprintf(stdout, _(      " -k, --skeleton       Adds an Ogg Skeleton bitstream\n"));
	fprintf(stdout, _(	" -r, --raw            Raw mode. Input files are read directly as PCM data\n"));
	fprintf(stdout, _(	" -F, --raw-format=n   Set format for raw input. Default is 1 for\n"));
	fprintf(stdout, _(	"                      Standard PCM; use 3 for IEEE Float.\n"));
	fprintf(stdout, _(	" -B, --raw-bits=n     Set bits/sample for raw input. Default is 16,\n"));
	fprintf(stdout, _(	"                      32 assumed for IEEE Float.\n"));
	fprintf(stdout, _(	" -C, --raw-chan=n     Set number of channels for raw input. Default is 2\n"));
	fprintf(stdout, _(	" -R, --raw-rate=n     Set samples/sec for raw input. Default is 44100\n"));
	fprintf(stdout, _(	" --raw-endianness     1 for bigendian, 0 for little (defaults to 0)\n"));
	fprintf(stdout, _(	" -b, --bitrate        Choose a nominal bitrate to encode at. Attempt\n"));
	fprintf(stdout, _(	"                      to encode at a bitrate averaging this. Takes an\n"));
	fprintf(stdout, _(	"                      argument in kbps. By default, this produces a VBR\n"));
	fprintf(stdout, _(	"                      encoding, equivalent to using -q or --quality.\n"));
	fprintf(stdout, _(	"                      See the --managed option to use a managed bitrate\n"));
	fprintf(stdout, _(	"                      targetting the selected bitrate.\n"));
	fprintf(stdout, _(	" --managed            Enable the bitrate management engine. This will allow\n"));
	fprintf(stdout, _(	"                      much greater control over the precise bitrate(s) used,\n"));
	fprintf(stdout, _(	"                      but encoding will be much slower. Don't use it unless\n"));
	fprintf(stdout, _(	"                      you have a strong need for detailed control over\n"));
	fprintf(stdout, _(	"                      bitrate, such as for streaming.\n"));
	fprintf(stdout, _(	" -m, --min-bitrate    Specify a minimum bitrate (in kbps). Useful for\n"));
	fprintf(stdout, _(	"                      encoding for a fixed-size channel.\n"));
	fprintf(stdout, _(	" -M, --max-bitrate    Specify a maximum bitrate in kbps. Useful for\n"));
	fprintf(stdout, _(	"                      streaming applications.\n"));
	fprintf(stdout, _(      " --advanced-encode-option option=value\n"));
	fprintf(stdout, _(      "                      Sets an advanced encoder option to the given value.\n"));
	fprintf(stdout, _(      "                      The valid options (and their values) are documented\n"));
	fprintf(stdout, _(      "                      in the man page supplied with this program. They are\n"));
	fprintf(stdout, _(      "                      for advanced users only, and should be used with\n"));
	fprintf(stdout, _(      "                      caution.\n"));
	fprintf(stdout, _(	" -q, --quality        Specify quality between -2 (low) and 10 (high),\n"));
	fprintf(stdout, _(	"                      instead of specifying a particular bitrate.\n"));
	fprintf(stdout, _(	"                      This is the normal mode of operation.\n"));
	fprintf(stdout, _(	"                      Fractional qualities (e.g. 2.75) are permitted\n"));
	fprintf(stdout, _(      "                      The default quality level is 3.\n"));
	fprintf(stdout, _(	" --resample n         Resample input data to sampling rate n (Hz)\n"));
	fprintf(stdout, _(	" -S, --converter      Specify the resampling engine to be used.\n"));
	fprintf(stdout, _(	"                      Options are: 0 (Best), 1 (Medium) & 2 (Fast).\n"));
	fprintf(stdout, _(	" --downmix            Downmix stereo to mono. Only allowed on stereo\n"));
	fprintf(stdout, _(	"                      input.\n"));
#ifdef INC_REHUFF
	fprintf(stdout, _(	" --rehuff             Do a second 'rehuff' pass on the .ogg file for\n"));
	fprintf(stdout, _(	"                      improved compression. ****EXPERIMENTAL OPTION.\n"));
#endif
	fprintf(stdout, _(	" --scale n            Scale input data to n (n = between 0.00 and 1.00)\n"));
	fprintf(stdout, _(	" --FLAC-scale n       Scale input data using FLAC Replaygain Tags where:\n"));
	fprintf(stdout, _(	"                      c = 1 to use Title Replaygain value, and\n"));
	fprintf(stdout, _(	"                      c = 2 to use Album Replaygain value.\n"));
	fprintf(stdout, _(	" -s, --serial         Specify a serial number for the stream. If encoding\n"));
	fprintf(stdout, _(	"                      multiple files, this will be incremented for each\n"));
	fprintf(stdout, _(	"                      stream after the first.\n"));
	fprintf(stdout, _(	" --discard-comments   Prevents comments in FLAC and Ogg FLAC files from\n"));
	fprintf(stdout, _(	"                      being copied to the output Ogg Vorbis file.\n"));
	fprintf(stdout, _(      " --ignorelength       Ignore the datalength in wav headers. This will allow\n"));
	fprintf(stdout, _(      "                      support for files > 4GB and STDIN data streams. \n"));
	fprintf(stdout, _(	"\n"));
	fprintf(stdout, _(	" Naming:\n"));
	fprintf(stdout, _(	" -o, --output=fn      Write file to fn (only valid in single-file mode)\n"));
	fprintf(stdout, _(	" -n, --names=string   Produce filenames as this string, with %%a, %%t, %%l,\n"));
	fprintf(stdout, _(	"                      %%n, %%d replaced by artist, title, album, track number,\n"));
	fprintf(stdout, _(	"                      and date, respectively (see below for specifying these).\n"));
	fprintf(stdout, _(	"                      %%%% gives a literal %%.\n"));
	fprintf(stdout, _(	" -X, --name-remove=s  Remove the specified characters from parameters to the\n"));
	fprintf(stdout, _(	"                      -n format string. Useful to ensure legal filenames.\n"));
	fprintf(stdout, _(	" -P, --name-replace=s Replace characters removed by --name-remove with the\n"));
	fprintf(stdout, _(	"                      characters specified. If this string is shorter than the\n"));
	fprintf(stdout, _(	"                      --name-remove list or is not specified, the extra\n"));
	fprintf(stdout, _(	"                      characters are just removed.\n"));
	fprintf(stdout, _(	"                      Default settings for the above two arguments are platform\n"));
	fprintf(stdout, _(	"                      specific.\n"));
	fprintf(stdout, _(	" --utf8               Tells oggenc that the command line parameters date,\n"));
	fprintf(stdout, _(	"                      title, album, artist, genre, and comment are already in\n"));
	fprintf(stdout, _(	"                      UTF8. On windows, this switch applies to file names too.\n"));
	fprintf(stdout, _(	" -c, --comment=c      Add the given string as an extra comment. This may be\n"));
	fprintf(stdout, _(	"                      used multiple times. The argument should be in the\n"));
	fprintf(stdout, _(        "                      format \"tag=value\".\n"));
	fprintf(stdout, _(	" -d, --date           Date for track (usually date of performance)\n"));
	fprintf(stdout, _(	" -N, --tracknum       Track number for this track\n"));
	fprintf(stdout, _(	" -t, --title          Title for this track\n"));
	fprintf(stdout, _(	" -l, --album          Name of album\n"));
	fprintf(stdout, _(	" -a, --artist         Name of artist\n"));
	fprintf(stdout, _(	" -G, --genre          Genre of track\n"));
	fprintf(stdout, _(      " -L, --lyrics         Include lyrics from given file (.srt or .lrc format)\n"));
	fprintf(stdout, _(      " -Y, --lyrics-language  Sets the language for the lyrics\n"));
	fprintf(stdout, _(	"                      If multiple input files are given, then multiple\n"));
	fprintf(stdout, _(	"                      instances of the previous five arguments will be used,\n"));
	fprintf(stdout, _(	"                      in the order they are given. If fewer titles are\n"));
	fprintf(stdout, _(	"                      specified than files, OggEnc will print a warning, and\n"));
	fprintf(stdout, _(	"                      reuse the final one for the remaining files. If fewer\n"));
	fprintf(stdout, _(	"                      track numbers are given, the remaining files will be\n"));
	fprintf(stdout, _(	"                      unnumbered. For the others, the final tag will be reused\n"));
	fprintf(stdout, _(	"                      for all others without warning (so you can specify a date\n"));
	fprintf(stdout, _(	"                      once, for example, and have it used for all the files)\n"));
/*	fprintf(stdout, _(	" -p, --padding n      Number of kilobytes of padding to provide in comment\n"));
	fprintf(stdout, _(	"                      header for post-encoding tagging. (0 - 4 permitted)\n")); ** Removed - Win 7 issues */
	fprintf(stdout, _(	"\n"));
	fprintf(stdout, _(	"INPUT FILES:\n"));
	fprintf(stdout, _(	" OggEnc input files must currently be 32, 24, 16, or 8 bit PCM WAV, AIFF, or\n"));
	fprintf(stdout, _(	" AIFF/C files, or 32 bit IEEE floating point WAV. Files may be mono or stereo\n"));
	fprintf(stdout, _(	" (or more channels) and any sample rate.\n"));
	fprintf(stdout, _(	" ALSO with this version, you may input FLAC, MONKEYS AUDIO, WAVPACK, LAPC,\n"));
	fprintf(stdout, _(	" OPTIMFROG and SHORTEN files. You MUST ensure that the appropriate\n"));
	fprintf(stdout, _(	" encoder/decoder (i.e., flac.exe, etc) is in the same dir/folder as\n"));
	fprintf(stdout, _(	" oggenc2.exe, or is in the defined path.\n"));
	fprintf(stdout, _(	" Alternatively, the --raw option may be used to use a raw PCM data file, which\n"));
	fprintf(stdout, _(	" must be 16bit stereo little-endian PCM ('headerless wav'), unless additional\n"));
	fprintf(stdout, _(	" parameters for raw mode are specified.\n"));
	fprintf(stdout, _(	" You can specify taking the file from stdin by using - as the input filename.\n"));
	fprintf(stdout, _(	" In this mode, output is to stdout unless an output filename is specified\n"));
	fprintf(stdout, _(	" with -o\n\n"));
}

static int strncpy_filtered(char *dst, char *src, int len, char *remove_list, 
        char *replace_list)
{
	char *hit, *drop_margin;
	int used=0;

	if(remove_list == NULL || *remove_list == 0)
	{
		strncpy(dst, src, len-1);
		dst[len-1] = 0;
		return strlen(dst);
	}

	drop_margin = remove_list + (replace_list == NULL?0:strlen(replace_list));

	while(*src && used < len-1)
	{
		if((hit = strchr(remove_list, *src)) != NULL)
		{
			if(hit < drop_margin)
			{
				*dst++ = replace_list[hit - remove_list];
				used++;
			}
		}
		else
		{
			*dst++ = *src;
			used++;
		}
		src++;
	}
	*dst = 0;

	return used;
}

static char *generate_name_string(char *format, char *remove_list,
        char *replace_list, char *artist, char *title, char *album, 
        char *track, char *date, char *genre)
{
	char *buffer;
	char next;
	char *string;
	int used=0;
	int buflen;

	buffer = calloc(CHUNK+1,1);
	buflen = CHUNK;

	while(*format && used < buflen)
	{
		next = *format++;

		if(next == '%')
		{
			switch(*format++)
			{
				case '%':
					*(buffer+(used++)) = '%';
					break;
				case 'a':
					string = artist?artist:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used, 
					        remove_list, replace_list);
					break;
				case 'd':
					string = date?date:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used,
					        remove_list, replace_list);
					break;
				case 'g':
					string = genre?genre:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used,
					        remove_list, replace_list);
					break;
				case 't':
					string = title?title:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used,
					        remove_list, replace_list);
					break;
				case 'l':
					string = album?album:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used,
					        remove_list, replace_list);
					break;
				case 'n':
					string = track?track:_("(none)");
					used += strncpy_filtered(buffer+used, string, buflen-used,
					        remove_list, replace_list);
					break;
				default:
					fprintf(stderr, _("WARNING: Ignoring illegal escape character '%c' in name format\n"), *(format - 1));
					break;
			}
		}
		else
			*(buffer + (used++)) = next;
	}

	return buffer;
}

/* static void parse_options(int argc, char **argv, oe_options *opt) */
static void parse_options(int *argc, char ***argv, int origargc, char **origargv, oe_options *opt)
{
	int ret;
	int option_index = 1;

	/* while((ret = getopt_long(argc, argv, "A:a:b:B:c:C:d:G:hl:m:M:n:N:o:p:P:q:QrR:s:S:t:vX:",  */
	/*while((ret = getopt_long(*argc, *argv, "A:a:b:B:c:C:d:F:G:hkl:L:m:M:n:N:o:p:P:q:QrR:s:S:t:vX:Y:",  */
	while((ret = getopt_long(*argc, *argv, "A:a:b:B:c:C:d:F:G:hkl:L:m:M:n:N:o:P:q:QrR:s:S:t:vX:Y:", 
					long_options, &option_index)) != -1)
	{
		switch(ret)
		{
			case 0:
				if(!strcmp(long_options[option_index].name, "skeleton")) {
					opt->with_skeleton = 1;
				}
				else if(!strcmp(long_options[option_index].name, "managed")) {
					if(!opt->managed){
						if(!opt->quiet)
							fprintf(stderr, 
							    _("Enabling bitrate management engine\n"));
						opt->managed = 1;
					}
				}
				else if(!strcmp(long_options[option_index].name, "raw-endianness")) {
					if (opt->rawmode != 1)
					{
						opt->rawmode = 1;
						fprintf(stderr, 
						    _("WARNING: Raw endianness specified for non-raw data. Assuming input is raw.\n"));
					}
					if(sscanf(optarg, "%d", &opt->raw_endianness) != 1) {
						fprintf(stderr, 
                                                    _("WARNING: Couldn't read endianness argument \"%s\"\n"), optarg);
						opt->raw_endianness = 0;
					}
				}
				else if(!strcmp(long_options[option_index].name, "resample")) {
					if(sscanf(optarg, "%d", &opt->resamplefreq) != 1) {
						fprintf(stderr, 
						    _("WARNING: Couldn't read resampling frequency \"%s\"\n"), optarg);
						opt->resamplefreq = 0;
					}
					if(opt->resamplefreq < 100) /* User probably specified it
					                               in kHz accidently */
						fprintf(stderr, 
						    _("Warning: Resample rate specified as %d Hz. Did you mean %d Hz?\n"), 
						        opt->resamplefreq, opt->resamplefreq*1000);
					}
				else if(!strcmp(long_options[option_index].name, "downmix")) {
					opt->downmix = 1;
				}
#ifdef INC_REHUFF
				else if(!strcmp(long_options[option_index].name, "rehuff")) {
					opt->rehuff = 1;
				}
#endif
				else if(!strcmp(long_options[option_index].name, "scale")) {
					opt->scale = atof(optarg);
					if(sscanf(optarg, "%f", &opt->scale) != 1) {
						opt->scale = 0;
						fprintf(stderr, _("Warning: Couldn't parse scaling factor \"%s\"\n"), 
							optarg);
					}
				}
				else if(!strcmp(long_options[option_index].name, "FLAC-scale")) {
					opt->FLAC_scale = atoi(optarg);
					if (opt->FLAC_scale < 0 || opt->FLAC_scale > 2) {
						fprintf(stderr, _("Warning: Couldn't invalid FLAC-scale parameter \"%s, ignoring.\"\n"), 
							optarg);
						opt->FLAC_scale = 0;
					}
				}
				else if(!strcmp(long_options[option_index].name, "utf8")) {
					opt->isutf8 = 1;
					if (*argc != origargc || *argv != origargv) {
						/* we had done translation to get UTF-8 from something else.
						   now we find out that we don't want to have done that translation.
						   undo everything; parse options from scratch. */
						*argc = origargc;
						*argv = origargv;
						option_index = 1;

						if (opt->advopt) {
							free(opt->advopt);
							opt->advopt = NULL;
							opt->advopt_count = 0;
						}
						if (opt->artist) {
							free(opt->artist);
							opt->artist = NULL;
							opt->artist_count = 0;
						}
						if (opt->dates) {
							free(opt->dates);
							opt->dates = NULL;
							opt->date_count = 0;
						}
						if (opt->comments) {
							free(opt->comments);
							opt->comments = NULL;
							opt->comment_count = 0;
						}
						if (opt->album) {
							free(opt->album);
							opt->album = NULL;
							opt->album_count = 0;
						}
						if (opt->genre) {
							free(opt->genre);
							opt->genre = NULL;
							opt->genre_count = 0;
						}
						if (opt->title) {
							free(opt->title);
							opt->title = NULL;
							opt->title_count = 0;
						}
						if (opt->tracknum) {
							free(opt->tracknum);
							opt->tracknum = NULL;
							opt->track_count = 0;
						}
					}
				}
				else if(!strcmp(long_options[option_index].name, "advanced-encode-option")) {
					char *arg = strdup(optarg);
					char *val;

					if(strcmp("disable_coupling",arg)){
						val = strchr(arg, '=');
						if(val == NULL) {
							fprintf(stderr, _("No value for advanced encoder option found\n"));
							continue;
						}
						else
							*val++=0;
					} else
						val=0;

					opt->advopt = realloc(opt->advopt, (++opt->advopt_count)*sizeof(adv_opt));
					opt->advopt[opt->advopt_count - 1].arg = arg;
					opt->advopt[opt->advopt_count - 1].val = val;
				}
				else if(!strcmp(long_options[option_index].name, "discard-comments")) {
					opt->copy_comments = 0;
				}
				else if(!strcmp(long_options[option_index].name, "ignorelength")) {
					opt->ignorelength = 1;
				}
				else {
					fprintf(stderr, 
					    _("Internal error parsing command line options\n"));
					exit(1);
				}

				break;
			case 'a':
				opt->artist = realloc(opt->artist, (++opt->artist_count)*sizeof(char *));
				opt->artist[opt->artist_count - 1] = strdup(optarg);
				break;
			case 'c':
				if(strchr(optarg, '=') == NULL) {
					fprintf(stderr, _("Warning: Illegal comment used (\"%s\"), ignoring.\n"), optarg);
					break;
				}
				opt->comments = realloc(opt->comments, (++opt->comment_count)*sizeof(char *));
				opt->comments[opt->comment_count - 1] = strdup(optarg);
				break;
			case 'd':
				opt->dates = realloc(opt->dates, (++opt->date_count)*sizeof(char *));
				opt->dates[opt->date_count - 1] = strdup(optarg);
				break;
			case 'G':
				opt->genre = realloc(opt->genre, (++opt->genre_count)*sizeof(char *));
				opt->genre[opt->genre_count - 1] = strdup(optarg);
				break;
			case 'h':
				usage();
				exit(0);
				break;
			case 'l':
				opt->album = realloc(opt->album, (++opt->album_count)*sizeof(char *));
				opt->album[opt->album_count - 1] = strdup(optarg);
				break;
			case 's':
				/* Would just use atoi(), but that doesn't deal with unsigned
				 * ints. Damn */
				if(sscanf(optarg, "%u", &opt->serial) != 1)
					opt->serial = 0; /* Failed, so just set to zero */
				else
					opt->fixedserial = 1;
				break;
			case 't':
				opt->title = realloc(opt->title, (++opt->title_count)*sizeof(char *));
				opt->title[opt->title_count - 1] = strdup(optarg);
				break;
			case 'b':
   				if(sscanf(optarg, "%d", &opt->nominal_bitrate) != 1) {
		    			fprintf(stderr, _("Warning: nominal bitrate \"%s\" not recognised\n"), optarg);
			    		opt->nominal_bitrate = -1;
				}

				break;
			case 'm':
				if(sscanf(optarg, "%d", &opt->min_bitrate)
						!= 1) {
					fprintf(stderr, _("Warning: minimum bitrate \"%s\" not recognised\n"), optarg);
					opt->min_bitrate = -1;
				}
				if(!opt->managed){
					if(!opt->quiet)
						fprintf(stderr, 
						    _("Enabling bitrate management engine\n"));
					opt->managed = 1;
				}
				break;
			case 'M':
				if(sscanf(optarg, "%d", &opt->max_bitrate) != 1) {
					fprintf(stderr, 
					    _("Warning: maximum bitrate \"%s\" not recognised\n"), optarg);
					opt->max_bitrate = -1;
				}
				if(!opt->managed){
					if(!opt->quiet)
						fprintf(stderr, 
						    _("Enabling bitrate management engine\n"));
					opt->managed = 1;
				}
				break;
			case 'V':
				if(sscanf(optarg, "%d", &opt->vbr_bitrate) != 1) {
					fprintf(stderr, 
					    _("Warning: approximate bitrate \"%s\" not recognised\n"), optarg);
					opt->vbr_bitrate = -1;
				}
				break;
			case 'q':
				if(sscanf(optarg, "%f", &opt->quality) != 1) {
					fprintf(stderr, 
					    _("Quality option \"%s\" not recognised, ignoring\n"), optarg);
					break;
				}
				opt->quality_set=1;
				opt->quality *= 0.1;
				if(opt->quality > 1.0f)
				{
					opt->quality = 1.0f;
					fprintf(stderr, 
					    _("WARNING: quality setting too high, setting to maximum quality.\n"));
				}
				else if(opt->quality < -0.2f)
				{
					opt->quality = -0.2f;
					fprintf(stderr, 
					    _("WARNING: quality setting too low, setting to minimum quality.\n"));
				}
				break;
			case 'S':
				if(sscanf(optarg, "%d", &opt->converter) != 1) {
					fprintf(stderr, 
					    _("Converter option \"%s\" not recognised, setting to Medium.\n"), optarg);
					opt->converter = 1;
				}
				if (opt->converter < 0 || opt->converter > 2) {
					fprintf(stderr, 
					    _("Converter option \"%d\" out of range, setting to Medium.\n"), optarg);
					opt->converter = 1;
				}
				break;
			case 'n':
				if(opt->namefmt)
				{
					fprintf(stderr, 
					    _("WARNING: Multiple name formats specified, using final\n"));
					free(opt->namefmt);
				}
				opt->namefmt = strdup(optarg);
				break;
			case 'X':
				if(opt->namefmt_remove && opt->namefmt_remove != DEFAULT_NAMEFMT_REMOVE)
				{
					fprintf(stderr, 
					    _("WARNING: Multiple name format filters specified, using final\n"));
					free(opt->namefmt_remove);
				}
				opt->namefmt_remove = strdup(optarg);
				break;
			case 'P':
				if(opt->namefmt_replace && opt->namefmt_replace != DEFAULT_NAMEFMT_REPLACE)
				{
					fprintf(stderr, 
					    _("WARNING: Multiple name format filter replacements specified, using final\n"));
					free(opt->namefmt_replace);
				}
				opt->namefmt_replace = strdup(optarg);
				break;
			case 'o':
				if(opt->outfile)
				{
					fprintf(stderr, 
					    _("WARNING: Multiple output files specified, suggest using -n\n"));
					free(opt->outfile);
				}
				opt->outfile = strdup(optarg);
				break;
			case 'p':
				if(sscanf(optarg, "%d", &opt->padding) != 1) {
					fprintf(stderr, 
					    _("Warning: Padding \"%s\" not recognised\n"), optarg);
					opt->padding = 0;
				}
				if(opt->padding > 4 || opt->padding < 0) {
					fprintf(stderr, 
					    _("Warning: Padding \"%s\" out of range, setting to 0\n"), optarg);
					opt->padding = 0;
				}
				break;
			case 'Q':
				opt->quiet = 1;
				break;
			case 'r':
				opt->rawmode = 1;
				break;
			case 'v':
				fprintf(stdout, VERSION_STRING);
				exit(0);
				break;
			case 'F':
				if (opt->rawmode != 1)
				{
					opt->rawmode = 1;
					fprintf(stderr, 
					    _("WARNING: Raw format specified for non-raw data. Assuming input is raw.\n"));
				}
				if(sscanf(optarg, "%u", &opt->raw_format) != 1)
				{
					opt->raw_format = 1; /* Failed, so just set to Standard PCM */
					fprintf(stderr, 
					    _("WARNING: Invalid format specified, assuming Standard PCM.\n"));
				}
				if((opt->raw_format != 1) && (opt->raw_format != 3))
				{
					fprintf(stderr, 
					    _("WARNING: Invalid format specified, assuming Standard PCM.\n"));
				}
				break;
			case 'B':
				if (opt->rawmode != 1)
				{
					opt->rawmode = 1;
					fprintf(stderr, 
					    _("WARNING: Raw bits/sample specified for non-raw data. Assuming input is raw.\n"));
				}
				if(sscanf(optarg, "%u", &opt->raw_samplesize) != 1)
				{
					opt->raw_samplesize = 16; /* Failed, so just set to 16 */
					fprintf(stderr, 
					    _("WARNING: Invalid bits/sample specified, assuming 16 (32 for IEEE Float).\n"));
				}
				if((opt->raw_samplesize != 8) && (opt->raw_samplesize != 16) &&
				   (opt->raw_samplesize != 24) && (opt->raw_samplesize != 32))
				{
					fprintf(stderr, 
					    _("WARNING: Invalid bits/sample specified, assuming 16 (32 for IEEE Float).\n"));
				}
				break;
			case 'C':
				if (opt->rawmode != 1)
				{
					opt->rawmode = 1;
					fprintf(stderr, 
					    _("WARNING: Raw channel count specified for non-raw data. Assuming input is raw.\n"));
				}
				if(sscanf(optarg, "%u", &opt->raw_channels) != 1)
				{
					opt->raw_channels = 2; /* Failed, so just set to 2 */
					fprintf(stderr, 
					    _("WARNING: Invalid channel count specified, assuming 2.\n"));
				}
				break;
			case 'N':
				opt->tracknum = realloc(opt->tracknum, (++opt->track_count)*sizeof(char *));
				opt->tracknum[opt->track_count - 1] = strdup(optarg);
				break;
			case 'R':
				if (opt->rawmode != 1)
				{
					opt->rawmode = 1;
					fprintf(stderr, 
					    _("WARNING: Raw sample rate specified for non-raw data. Assuming input is raw.\n"));
				}
				if(sscanf(optarg, "%u", &opt->raw_samplerate) != 1)
				{
					opt->raw_samplerate = 44100; /* Failed, so just set to 44100 */
					fprintf(stderr, 
					    _("WARNING: Invalid sample rate specified, assuming 44100.\n"));
				}
				break;
			case 'k':
				opt->with_skeleton = 1;
				break;
			case 'L':
#ifdef HAVE_KATE
				opt->lyrics = realloc(opt->lyrics, (++opt->lyrics_count)*sizeof(char *));
				opt->lyrics[opt->lyrics_count - 1] = strdup(optarg);
				opt->with_skeleton = 1;
#else
				fprintf(stderr, _("WARNING: Kate support not compiled in; lyrics will not be included.\n"));
#endif
				break;
			case 'Y':
#ifdef HAVE_KATE
				opt->lyrics_language = realloc(opt->lyrics_language, (++opt->lyrics_language_count)*sizeof(char *));
				opt->lyrics_language[opt->lyrics_language_count - 1] = strdup(optarg);
				if (strlen(opt->lyrics_language[opt->lyrics_language_count - 1]) > 15) {
					fprintf(stderr, _("WARNING: language can not be longer than 15 characters; truncated.\n"));
					opt->lyrics_language[opt->lyrics_language_count - 1][15] = 0;
				}
#else
				fprintf(stderr, _("WARNING: Kate support not compiled in; lyrics will not be included.\n"));
#endif
				break;
			case '?':
				fprintf(stderr, 
				    _("WARNING: Unknown option specified, ignoring->\n"));
				break;
			default:
				usage();
				exit(0);
		}
	}
}

static void add_tag(vorbis_comment *vc, oe_options *opt,char *name, char *value)
{
	char *utf8;
	/* if(utf8_encode(value, &utf8) >= 0) */
	if (opt->isutf8) {
		if (!utf8_validate(value)) {
			fprintf(stderr, _("'%s' is not valid UTF-8, cannot add\n"), name?name:"comment");
		} else {
			if(name == NULL)
				vorbis_comment_add(vc, value);
			else
				vorbis_comment_add_tag(vc, name, value);
		}
	}
	else if(utf8_encode(value, &utf8) >= 0)
	{
		if(name == NULL)
			vorbis_comment_add(vc, utf8);
		else
			vorbis_comment_add_tag(vc, name, utf8);
		free(utf8);
	}
	else
		fprintf(stderr, _("Couldn't convert comment to UTF-8, cannot add\n"));
}

static void build_comments(vorbis_comment *vc, oe_options *opt, int filenum, 
		char **artist, char **album, char **title, char **tracknum, 
        	char **date, char **genre)
{
	int i;

	vorbis_comment_init(vc);

	for(i = 0; i < opt->comment_count; i++)
		add_tag(vc, opt, NULL, opt->comments[i]);

	if(opt->title_count)
	{
		if(filenum >= opt->title_count)
		{
			if(!opt->quiet)
				fprintf(stderr, _("WARNING: Insufficient titles specified, defaulting to final title.\n"));
			i = opt->title_count-1;
		}
		else
			i = filenum;

		*title = opt->title[i];
		add_tag(vc, opt, "title", opt->title[i]);
	}

	if(opt->artist_count)
	{
		if(filenum >= opt->artist_count)
			i = opt->artist_count-1;
		else
			i = filenum;
	
		*artist = opt->artist[i];
		add_tag(vc, opt, "artist", opt->artist[i]);
	}

	if(opt->genre_count)
	{
		if(filenum >= opt->genre_count)
			i = opt->genre_count-1;
		else
			i = filenum;

		*genre = opt->genre[i];
		add_tag(vc, opt, "genre", opt->genre[i]);
	}

	if(opt->date_count)
	{
		if(filenum >= opt->date_count)
			i = opt->date_count-1;
		else
			i = filenum;
	
		*date = opt->dates[i];
		add_tag(vc, opt, "date", opt->dates[i]);
	}
	
	if(opt->album_count)
	{
		if(filenum >= opt->album_count)
		{
			i = opt->album_count-1;
		}
		else
			i = filenum;

		*album = opt->album[i];	
		add_tag(vc, opt, "album", opt->album[i]);
	}

	if(filenum < opt->track_count)
	{
		i = filenum;
		*tracknum = opt->tracknum[i];
		add_tag(vc, opt, "tracknumber", opt->tracknum[i]);
	}
}

