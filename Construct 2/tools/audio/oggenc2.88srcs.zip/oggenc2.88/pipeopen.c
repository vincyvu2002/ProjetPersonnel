#ifdef _WIN32
#include <windows.h>
#endif
#include "audio.h"
#include <ctype.h>
#include "i18n.h"

/*
 *  Executes command line given by �command�.
 *  The command must be found in some predefined paths or in the ${PATH} aka %PATH%
 *  The char �#� in command is replaced by the contents
 *  of �filename�. Special characters are escaped.
 */


FILE*
pipeopen ( const char* command, const char* filename )
{
	static char*  paths [] = {
#ifdef _WIN32
		"C:\\WIN\\"    , "C:\\WIN\\SYSTEM32\\"    ,
		"C:\\WINDOWS\\", "C:\\WINDOWS\\SYSTEM32\\",
		"C:\\WINNT\\"  , "C:\\WINNT\\SYSTEM32\\"  ,
		"C:\\WIN2000\\", "C:\\WIN2000\\SYSTEM32\\",
		"C:\\WIN95\\"  , "C:\\WIN95\\SYSTEM32\\"  ,
		"C:\\WIN98\\"  , "C:\\WIN98\\SYSTEM32\\"  ,
		"C:\\WINME\\"  , "C:\\WINME\\SYSTEM32\\"  ,
		"C:\\PROGRAM\" \"FILES\\AUDIO\\",
		"C:\\PROGRAMME\\AUDIO\\",
		".\\",
#else
		"/usr/bin/", "/usr/local/bin/", "/opt/mpp/", "./"
#endif
	};
	char          buff1 [4096];
	char          buff2 [4096 + 16];
	char          buff3 [4096];
	char*         p;
	const char*   q;
	unsigned long len;
	FILE*         fp;
	int           i;
	const char*   env;

	// does the source file exist and is it readable?
	if ( (fp = fopen (filename, "rb")) == NULL ) {
		fprintf(stderr, _("file %s not found.\n"), filename );
		return NULL;
	}
	fclose (fp);

	// extract executable name from the 'command' to buff3, append executable extention
	for ( p = buff3, q = command; *q != ' ' && *q; q++ )
        	*p++ = *q;
	strcpy (p, EXE_EXT);

	// Copy 'command' to 'buff1' replacing '#' by filename
	for ( p = buff1; *command; command++ )
		if ( *command != '#' ) {
			*p++ = *command;
		} else {
			q = filename;
			if (*q == '-') {
				*p++ = '.';
				*p++ = PATH_SEP;
			}
#ifdef _WIN32                           // Windows secure Way to "escape"
			*p++ = '"';
			while (*q)
				*p++ = *q++;
			*p++ = '"';
#else                                   // Unix secure Way to \e\s\c\a\p\e
			while (*q) {
				if ( !isalnum(*q) && *q != '.' && *q != '-' && *q != '_' && *q != '/' )
					*p++ = '\\';
				p++ = *q++;
			}
#endif
		}
	*p = '\0';

	// Try the several built-in paths to find binary
	for ( i = 0; i < sizeof(paths)/sizeof(*paths); i++ ) {
		strcpy ( buff2, paths[i] );
		len = strlen (paths[i]);
		strcpy ( buff2+len, buff3 );
#ifdef DEBUG2
		fprintf(stderr, _("Test for %s...        \n"), buff2 );
#endif
		fp = fopen ( buff2, "r" );
		if ( fp != NULL ) {
			fclose ( fp );
			strcpy ( buff2+len, buff1 );
#ifdef DEBUG2
			fprintf(stderr, _("Execute %s\n"), buff2 );
#endif
			fp = POPEN_READ_BINARY_OPEN (buff2);
			if ( fp != NULL )
				return fp;
		}
	}

	// Try the PATH settings to find binary (Why we must search for the executable in all PATH settings? --> popen itself do not return useful information)
	env = getenv ("PATH");
	while ( env != NULL   &&  *env != '\0' ) {
#ifdef _WIN32
		p = strchr (env, ';');
#else
		p = strchr (env, ':');
#endif
		if ( p == NULL )
			strcpy (buff2, env), len = strlen(env), env = NULL;
		else
			memcpy (buff2, env, len = p-env ), env = p+1;

		buff2 [len++] = PATH_SEP;
		strcpy ( buff2+len, buff3 );
#ifdef DEBUG2
		fprintf(stderr, _("Test for %s...        \n"), buff2 );
#endif
		fp = fopen ( buff2, "r" );
		if ( fp != NULL ) {
			fclose ( fp );
			strcpy ( buff2+len, buff1 );
#ifdef DEBUG2
			fprintf(stderr, _("Execute %s\n"), buff2 );
#endif
			fp = POPEN_READ_BINARY_OPEN (buff2);
			if ( fp != NULL )
				return fp;
		}
	}

#ifdef DEBUG2
	fprintf(stderr, _("Nothing found to execute\n",));
#endif
	return NULL;
}

/* end of pipeopen.c */
