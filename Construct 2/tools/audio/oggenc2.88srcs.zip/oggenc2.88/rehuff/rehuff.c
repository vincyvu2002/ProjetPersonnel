/* This code is Copyright 2002 by Segher Boessenkool */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "sogg.h"
#include "count.h"
#include "recode.h"
#include "headers.h"

int verbose;

int rehuff(char *in_file, char *out_file, unsigned int serial, int quiet)
{
	struct sogg sogg_in, sogg_out;
	ogg_packet op_in, op_out;
	FILE *fp_in, *fp_out;
	struct headers headers;
	long **count;

	if(quiet)
		verbose = 0;
	else
		verbose = 1;

	fp_in = fopen(in_file, "rb");
	if (fp_in == 0) {
		perror(in_file);
		exit(1);
	}
	fp_out = fopen(out_file, "wb");
	if (fp_out == 0) {
		perror(out_file);
		exit(1);
	}

	/* first, read the input, counting the huffwords encountered */

	sogg_init_read(&sogg_in, fp_in);

	sogg_read_first(&sogg_in, &op_in);
	if (header0_read(&op_in, &headers) < 0)
		exit(1);

	sogg_read(&sogg_in, &op_in);
	if (header1_read(&op_in, &headers) < 0)
		exit(1);

	sogg_read(&sogg_in, &op_in);
	if (header2_read(&op_in, &headers) < 0)
		exit(1);

	count = init_count(&headers);

	while (sogg_read(&sogg_in, &op_in))
		count_packet(&op_in, &headers, count);

	sogg_fini_read(&sogg_in);

//show_it(&headers, count);

	/* now, do processing */

	init_recode(&headers, count);

	/* then, read input again, and write output */

//	fseek(fp_in, 0, 0);
	rewind(fp_in);

	sogg_init_read(&sogg_in, fp_in);
	sogg_init_write(&sogg_out, fp_out, serial);

	sogg_read_first(&sogg_in, &op_in);
	if (header0_recode(&op_in, &op_out, &headers) < 0)
		exit(1);
	sogg_write(&sogg_out, &op_out);

	sogg_read(&sogg_in, &op_in);
	if (header1_recode(&op_in, &op_out, &headers) < 0)
		exit(1);
	sogg_write(&sogg_out, &op_out);

	sogg_read(&sogg_in, &op_in);
	if (header2_recode(&op_in, &op_out, &headers) < 0)
		exit(1);
	sogg_write(&sogg_out, &op_out);

	sogg_flush(&sogg_out);  //another addition

	while (sogg_read(&sogg_in, &op_in)) {
		recode_packet(&op_in, &op_out, &headers);
		sogg_write(&sogg_out, &op_out);
	}

	sogg_fini_read(&sogg_in);
	sogg_fini_write(&sogg_out);

	/* finally, clean up */

	fclose(fp_out);
	fclose(fp_in);

	return 0;
}
